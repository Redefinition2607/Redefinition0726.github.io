// ==UserScript==
// @name         洛谷签到转换器
// @namespace    http://tampermonkey.net/
// @version      1.0.1
// @description  让你的签到有趣起来
// @author       VitamineC(?
// @match        https://*.luogu.com.cn/*
// @grant        none
// ==/UserScript==


$(window).load(function()
{
    'use strict';
    /*求大神自己添加下洛谷签到按钮onclick->update() qwq*/
    function update(){
    var luckno=document.querySelector("#app-old > div.lg-index-content.am-center > div:nth-child(1) > div > div > div > div.am-u-md-4.lg-punch.am-text-center > span");
    if(luckno!=null){
        var today=luckno.innerText;
        if(today=='§ 大吉 §'){
            luckno.innerText='§ 好大の吉 §';
        }else if(today=='§ 中吉 §'){
            luckno.innerText='§ 吉吧 §';
        }else if(today=='§ 小吉 §'){
            luckno.innerText='§ 小吉吧 §';
        }else if(today=='§ 中平 §'){
            luckno.innerText='§ 草 §';
        }else if(today=='§ 凶 §'){
            luckno.innerText='§ 爬开 §';
        }else if(today=='§ 大凶 §'){
            luckno.innerText='§ 逊爆了 §';
        }
    }
    }
    update();
});
