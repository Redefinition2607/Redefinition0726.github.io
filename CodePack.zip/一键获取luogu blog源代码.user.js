// ==UserScript==
// @name         一键获取luogu blog源代码
// @namespace    https://www.luogu.com.cn/blog/Rainwangpupil/copy-markdown-luogu-blog
// @license      MIT
// @version      0.1
// @description  在他人洛谷博客页面使用 Ctrl + Alt + C 快捷键，一键复制博客源代码！
// @author       Luogu Username: 2044_space_elevator
// @match        https://www.luogu.com.cn/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    const url = window.location.href;
    async function clickBotton_blog(){
        fetch('/api/blog/detail/' + BlogGlobals.blogID).then(res => res.json()).then(res => navigator.clipboard.writeText(res.data.Content));
            // console.log(f);
            // navigator.clipboard.writeText(res.data.content)
    };
    if (url.includes("blog"))
    {
        document.onkeydown = function(e)
        {
            if (e.keyCode == 67 && e.ctrlKey && e.altKey)
            {
                clickBotton_blog();
                alert("复制成功！");
            }
        }
    }


})();